import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.println("ДЗ №2 Вариант 5 Богаенко Е.К. Рибо-01-21");
        System.out.println("Введите название магазина");
            Scanner scan = new Scanner(System.in);
        String nameStore = scan.nextLine();
        System.out.println("Введите город магазина");
            Scanner scan1 = new Scanner(System.in);
        String cityStore = scan1.nextLine();
        System.out.println("Введите специализацию магазина");
            Scanner scan2 = new Scanner(System.in);
        String specializationStore = scan2.nextLine();
        Store supermarket = new Store(nameStore, cityStore, specializationStore);
        supermarket.sell();
        supermarket.sale();
        supermarket.acceptance();
        System.out.println("Какой магазин вы хотите создать? Наберите 1, если продуктовый; Наберите 2, если автомобильный");
        Scanner scan0 = new Scanner(System.in);
                int chooseStore = scan0.nextInt();
                if (chooseStore == 1){
                    System.out.println("Введите наиболее продаваемый товар");
                        Scanner scan3 = new Scanner(System.in);
                    String bestSeller = scan3.nextLine();
                    System.out.println("Введите время открытия");
                        Scanner scan4 = new Scanner(System.in);
                    Integer openingTime = scan4.nextInt();
                        Supermarket std = new Supermarket(nameStore, cityStore, specializationStore,bestSeller, openingTime);
                    System.out.println(std.toString());
                }
                else {
                    System.out.println("Введите страну производства автомобиля");
                        Scanner scan5 = new Scanner(System.in);
                    String country = scan5.nextLine();
                    System.out.println("Введите пробег автомобиля");
                        Scanner scan6 = new Scanner(System.in);
                    Integer mileage = scan6.nextInt();
                    Cars std1 = new Cars(nameStore, cityStore, specializationStore, country, mileage);
                    System.out.println(std1.toString());
                }
    }

}