public class Supermarket extends Store{
    private String bestSeller;
    private int openingTime;

    public Supermarket(String nameStore, String cityStore, String specializationStore, String bestSeller, Integer openingTime) {
        super(nameStore, cityStore, specializationStore );
        this.bestSeller=bestSeller;
        this.openingTime=openingTime;
    }
    public String getBestSeller() {
        return bestSeller;
    }

    public int getOpeningTime() {
        return openingTime;
    }
    @Override
    public String toString(){
        String str = " Название магазина - "+ getName() + " Название магазина - "+ getCity() + " Специализация - "+ getSpecialization() + " Наиболее продаваемый товар - " + getBestSeller() + " Время открытия магазина - " + getOpeningTime();
        return str;
    }
}
