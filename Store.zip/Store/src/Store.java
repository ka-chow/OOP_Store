public class Store {
    private String name;
    private String city;
    private String specialization;

    public Store(String name, String city, String specialization) {
        this.name = name;
        this.city = city;
        this.specialization = specialization;
    }

    public String getName() {
        return name;
    }

    public String getCity() {
        return city;
    }

    public String getSpecialization() {
        return specialization;
    }
    public void sell(){
        System.out.println("Supermarket sells");
    }
    public void sale(){
        System.out.println("Supermarket sales");
    }
    public void acceptance(){
        System.out.println("Supermarket acceptances");
    }
}
