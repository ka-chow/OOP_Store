public class Cars extends Store{
    private String country;
    private Integer mileage;
    public Cars(String name, String city, String specialization, String country, Integer mileage) {
        super(name, city, specialization);
        this.country=country;
        this.mileage=mileage;
    }

    public String getCountry() {
        return country;
    }

    public Integer getMileage() {
        return mileage;
    }
    @Override
    public String toString(){
        String str1 = " Название магазина - "+ getName() + " Название магазина - "+ getCity() + " Специализация - "+ getSpecialization() + " Страна производства - " + getCountry() + " Пробег - " + getMileage();
        return str1;
    }
}
